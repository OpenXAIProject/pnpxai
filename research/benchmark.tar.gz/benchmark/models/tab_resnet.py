import torch
import torch.nn as nn
import numpy as np

class ResNetBlock(nn.Module):
    def __init__(self, in_features, out_features):
        super(ResNetBlock, self).__init__()
        self.bn = nn.BatchNorm1d(in_features)
        self.fc1 = nn.Linear(in_features, out_features)
        self.fc2 = nn.Linear(out_features, out_features)
        self.dropout = nn.Dropout(0.2)
        
    def forward(self, x):
        # if x.ndim >= 3:
        #     x = x.squeeze(1)
        y = torch.relu(self.fc1(self.bn(x)))
        y = self.dropout(y)
        y = self.fc2(y)
        y = self.dropout(y)
        return torch.add(x, y)

    
class TabResNet(nn.Module):
    def __init__(self, in_features, out_features, num_blocks=1, embedding_dim=128):
        super(TabResNet, self).__init__()
        self.embedding = nn.Linear(in_features, embedding_dim)
        self.res_blocks = []
        for i in range(num_blocks):
            self.res_blocks.append(ResNetBlock(embedding_dim, embedding_dim))
        self.res_blocks = nn.ModuleList(self.res_blocks)
        self.bn = nn.BatchNorm1d(embedding_dim)
        self.fc = nn.Linear(embedding_dim, out_features)
        
    def network(self, x):
        x = self.embedding(x)
        for block in self.res_blocks:
            x = block(x)
        x = torch.relu(self.bn(x))
        x = self.fc(x)
        return x
    
    def forward(self, x):
        return torch.softmax(self.network(x), dim=1)
    
    def predict_proba(self, x):
        # Currently used by SHAP
        input = x if torch.is_tensor(x) else torch.from_numpy(np.array(x))
        return self.forward(input.float()).detach().numpy()
    
    def predict(self, x, argmax=False):
        # Currently used by LIME
        input = torch.squeeze(x) if torch.is_tensor(x) else torch.from_numpy(np.array(x))
        output = self.forward(input.float()).detach().numpy()
        return output.argmax(axis=-1) if argmax else output
    


class LogisticRegression(torch.nn.Module):
    def __init__(self, input_dim, output_dim):
        super(LogisticRegression, self).__init__()
        self.linear = torch.nn.Linear(input_dim, output_dim)

    def network(self, x):
        return self.linear(x)
    
    def forward(self, x):
        return torch.softmax(self.network(x), dim=1)
    
    def predict_proba(self, x):
        # Currently used by SHAP
        input = x if torch.is_tensor(x) else torch.from_numpy(np.array(x))
        return self.forward(input.float()).detach().numpy()
    
    def predict(self, x, argmax=False):
        # Currently used by LIME
        input = torch.squeeze(x) if torch.is_tensor(x) else torch.from_numpy(np.array(x))
        output = self.forward(input.float()).detach().numpy()
        return output.argmax(axis=-1) if argmax else output

